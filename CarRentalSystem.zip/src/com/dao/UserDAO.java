package com.dao;
import java.sql.*;
public class UserDAO {
    private Connection conn;
    public UserDAO(Connection conn) { this.conn = conn; }
    public boolean login(String email, String password) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    public boolean register(String name, String email, String password) {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users(name, email, password) VALUES (?, ?, ?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            int i = ps.executeUpdate();
            return i > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
}
