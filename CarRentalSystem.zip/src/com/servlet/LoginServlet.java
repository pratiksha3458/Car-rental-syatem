package com.servlet;
import javax.servlet.*; import javax.servlet.http.*;
import java.io.*; import java.sql.*;
import com.dao.UserDAO;
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental", "root", "");
            UserDAO dao = new UserDAO(conn);
            if (dao.login(email, password)) {
                res.getWriter().println("Login successful!");
            } else {
                res.getWriter().println("Login failed. Invalid credentials.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
